AOS.init();
new PureCounter();